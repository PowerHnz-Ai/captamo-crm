/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './auth.html',
    './app.js',
    './auth.js'
  ],
  theme: {
    extend: {
      colors: {
        app: {
          bg: 'var(--bg-primary)',
          secondary: 'var(--bg-secondary)',
          card: 'var(--bg-card)',
          border: 'var(--border)',
          text: 'var(--text-primary)',
          muted: 'var(--text-muted)',
          subtle: 'var(--text-secondary)',
          accent: 'var(--accent)',
          accentHover: 'var(--accent-hover)'
        }
      },
      fontFamily: {
        sans: ['DM Sans', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif']
      },
      boxShadow: {
        app: '0 10px 30px rgba(0,0,0,0.25)'
      }
    }
  },
  plugins: []
};
