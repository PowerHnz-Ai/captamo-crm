// Configuração do Firebase
// Crie um projeto em https://console.firebase.google.com
// Ative Authentication (Email/Password) e Firestore Database
// Copie suas credenciais abaixo

const firebaseConfig = {
  apiKey: "AIzaSyD7CyGCBMbKpkpqs2igcz4zNdZo85_-GQE",
  authDomain: "checklist-de82b.firebaseapp.com",
  projectId: "checklist-de82b",
  storageBucket: "checklist-de82b.firebasestorage.app",
  messagingSenderId: "387860097899",
  appId: "1:387860097899:web:8c320ef336f196ad467a2e",
  measurementId: "G-V7M0EQ20NN"
};