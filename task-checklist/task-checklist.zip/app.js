// Estado da aplicação
const state = {
  currentDate: new Date(),
  selectedDate: new Date(),
  mobileSection: 'agenda',
  tasks: [],
  readyTasks: [],
  filter: 'all',
  editingTaskId: null,
  editingReadyTaskId: null,
  userProfile: null,
  workingDays: null,
  user: null,
  companyUsers: [],
  viewingUserId: null,
  viewingUserName: null
};

const STORAGE_KEY = 'task-checklist-data';
const SETTINGS_KEY = 'task-checklist-settings';
const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const MONTHS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const ACCENT_PRESETS = {
  indigo: { accent: '#6366f1', hover: '#818cf8', soft: 'rgba(99, 102, 241, 0.15)' },
  blue: { accent: '#3b82f6', hover: '#60a5fa', soft: 'rgba(59, 130, 246, 0.15)' },
  emerald: { accent: '#10b981', hover: '#34d399', soft: 'rgba(16, 185, 129, 0.15)' },
  orange: { accent: '#f59e0b', hover: '#fbbf24', soft: 'rgba(245, 158, 11, 0.15)' },
  pink: { accent: '#ec4899', hover: '#f472b6', soft: 'rgba(236, 72, 153, 0.15)' },
  violet: { accent: '#8b5cf6', hover: '#a78bfa', soft: 'rgba(139, 92, 246, 0.15)' },
  'rgb-red': { accent: '#ef4444', hover: '#f87171', soft: 'rgba(239, 68, 68, 0.15)' },
  'rgb-green': { accent: '#22c55e', hover: '#4ade80', soft: 'rgba(34, 197, 94, 0.15)' },
  'rgb-blue': { accent: '#3b82f6', hover: '#60a5fa', soft: 'rgba(59, 130, 246, 0.15)' }
};

function refreshIcons() {
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }
}

function getAppBasePath() {
  const path = window.location.pathname || '/';
  const cleaned = path.replace(/(?:index|auth)\.html$/i, '').replace(/auth\/?$/i, '');
  return cleaned.endsWith('/') ? cleaned : `${cleaned}/`;
}

function getAppRoute(route) {
  const fileName = route === 'auth' ? 'auth.html' : 'index.html';
  if (window.location.protocol === 'file:') {
    return new URL(fileName, window.location.href).href;
  }

  const base = getAppBasePath();
  return route === 'auth' ? `${base}auth` : base;
}

function navigateToRoute(route) {
  window.location.href = getAppRoute(route);
}

function normalizeCanonicalUrl() {
  if (window.location.protocol === 'file:') return;

  const pathname = window.location.pathname || '/';
  let canonicalPath = null;

  if (/\/index\.html$/i.test(pathname)) {
    canonicalPath = pathname.replace(/index\.html$/i, '');
  } else if (/\/auth\.html$/i.test(pathname)) {
    canonicalPath = pathname.replace(/auth\.html$/i, 'auth');
  }

  if (canonicalPath == null) return;
  if (canonicalPath === '') canonicalPath = '/';

  const normalized = canonicalPath + window.location.search + window.location.hash;
  window.history.replaceState(null, '', normalized);
}

// Versículos e frases do dia (rotaciona conforme o dia do ano)
const VERSICULOS_BIBLICOS = [
  '“O Senhor é o meu pastor; nada me faltará.” — Salmos 23:1',
  '“Esforçai-vos e tende bom ânimo; não temais.” — Josué 1:9',
  '“Tudo posso naquele que me fortalece.” — Filipenses 4:13',
  '“O Senhor está perto de todos os que o invocam.” — Salmos 145:18',
  '“Vinde a mim, todos os que estais cansados, e eu vos aliviarei.” — Mateus 11:28',
  '“O amor é paciente, o amor é bondoso.” — 1 Coríntios 13:4',
  '“Confia no Senhor de todo o teu coração.” — Provérbios 3:5',
  '“Este é o dia que o Senhor fez; regozijemo-nos nele.” — Salmos 118:24',
  '“A paz de Deus guardará o vosso coração.” — Filipenses 4:7',
  '“O Senhor é a minha luz e a minha salvação.” — Salmos 27:1',
  '“Não andeis ansiosos por coisa alguma.” — Filipenses 4:6',
  '“Buscai primeiro o reino de Deus.” — Mateus 6:33',
  '“O fruto do Espírito é amor, alegria, paz.” — Gálatas 5:22',
  '“O Senhor te guardará de todo mal.” — Salmos 121:7',
  '“Com Cristo posso enfrentar qualquer coisa.” — Filipenses 4:13'
];

const FRASES_MOTIVACIONAIS = [
  'Hoje é um ótimo dia para começar.',
  'Um passo de cada vez leva você longe.',
  'Seu esforço de hoje é seu sucesso de amanhã.',
  'Acredite: você é capaz.',
  'Cada tarefa concluída é uma vitória.',
  'Organize o dia e ganhe paz de espírito.',
  'Pequenos progressos ainda são progressos.',
  'Comece onde você está. Use o que você tem.',
  'O melhor momento para agir é agora.',
  'Celebre as pequenas conquistas.',
  'Foco e consistência mudam o jogo.',
  'Respire, organize e siga em frente.',
  'Você está mais perto do que imagina.',
  'Um dia de cada vez, uma tarefa de cada vez.',
  'Seu trabalho de hoje importa.'
];

function getDayOfYear(date) {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date - start;
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

function getDailyMessage() {
  const today = new Date();
  const dayOfYear = getDayOfYear(today);
  const useVerse = today.getDate() % 2 === 0; // dias pares: versículo; ímpares: frase
  const list = useVerse ? VERSICULOS_BIBLICOS : FRASES_MOTIVACIONAIS;
  const index = dayOfYear % list.length;
  return list[index];
}

function updateDailyMessage() {
  const el = document.getElementById('dailyMessage');
  if (el) {
    el.textContent = getDailyMessage();
  }
}

// Utilitários de data
function getDefaultWorkingDays() {
  // Segunda (1) até Sexta (5)
  return [1, 2, 3, 4, 5];
}

function formatDateKey(date) {
  const key = date.toISOString().split('T')[0];
  return key;
}

function isSameDay(d1, d2) {
  return d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate();
}

function getWeekStart(date) {
  const d = new Date(date);
  const day = d.getDay();
  d.setDate(d.getDate() - day);
  return d;
}

/** Interpreta "YYYY-MM-DD" como data local (meio-dia), alinhado a tarefas com data específica. */
function parseDateKeyLocal(key) {
  if (!key || typeof key !== 'string') return null;
  const parts = key.split('-').map(Number);
  if (parts.length !== 3 || parts.some(n => Number.isNaN(n))) return null;
  const d = new Date(parts[0], parts[1] - 1, parts[2], 12, 0, 0, 0);
  return isNaN(d.getTime()) ? null : d;
}

function calendarDaysBetween(fromDate, toDate) {
  const a = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate());
  const b = new Date(toDate.getFullYear(), toDate.getMonth(), toDate.getDate());
  return Math.round((b.getTime() - a.getTime()) / 86400000);
}

/** Primeira ocorrência de weekDay (0–6) em refDate ou nos dias seguintes. */
function firstWeekDayOnOrAfter(refDate, weekDay) {
  const d = new Date(refDate.getFullYear(), refDate.getMonth(), refDate.getDate(), 12, 0, 0, 0);
  for (let i = 0; i < 7; i++) {
    if (d.getDay() === weekDay) return new Date(d);
    d.setDate(d.getDate() + 1);
  }
  return new Date(refDate.getFullYear(), refDate.getMonth(), refDate.getDate(), 12, 0, 0, 0);
}

function matchesBiweeklyOnDate(task, date) {
  if (task.weekDay !== date.getDay()) return false;
  const anchor = parseDateKeyLocal(task.biweeklyStart);
  if (!anchor) return false;
  const diff = calendarDaysBetween(anchor, date);
  if (diff < 0) return false;
  return diff % 14 === 0;
}

function mapLoadedTask(t) {
  const task = { ...t, completedDates: t.completedDates || [] };
  if (task.frequency === 'biweekly' && task.weekDay != null && !task.biweeklyStart) {
    task.biweeklyStart = formatDateKey(firstWeekDayOnOrAfter(new Date(), task.weekDay));
  }
  return task;
}

// Configurações / tema
function loadSettings() {
  try {
    const s = localStorage.getItem(SETTINGS_KEY);
    if (!s) return { theme: 'dark', accent: '#22c55e', fontSize: 'medium' };
    const parsed = JSON.parse(s);
    if (parsed && typeof parsed.accent === 'string' && ACCENT_PRESETS[parsed.accent]) {
      parsed.accent = ACCENT_PRESETS[parsed.accent].accent;
    }
    if (!parsed.accent) parsed.accent = '#22c55e';
    return parsed;
  } catch (e) {
    return { theme: 'dark', accent: '#22c55e', fontSize: 'medium' };
  }
}

function saveSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  applySettings(settings);
  if (typeof updateUserRoleAndCode === 'function') {
    updateUserRoleAndCode();
  }
}

function applySettings(settings) {
  document.documentElement.setAttribute('data-theme', settings.theme);
  document.documentElement.setAttribute('data-font-size', settings.fontSize);
  const palette = getAccentPalette(settings.accent);
  document.documentElement.style.setProperty('--accent', palette.accent);
  document.documentElement.style.setProperty('--accent-hover', palette.hover);
  document.documentElement.style.setProperty('--accent-soft', palette.soft);
  document.documentElement.style.setProperty('--accent-contrast', palette.contrast);
  document.documentElement.style.setProperty('--accent-hover-contrast', palette.hoverContrast);
  if (settings.theme === 'dark') {
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#0f0f12');
  } else if (settings.theme === 'light') {
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#f4f4f5');
  }
}

function normalizeHexColor(value) {
  if (!value || typeof value !== 'string') return null;
  const v = value.trim();
  if (!/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(v)) return null;
  if (v.length === 4) {
    return '#' + v.slice(1).split('').map(ch => ch + ch).join('').toLowerCase();
  }
  return v.toLowerCase();
}

function hexToRgb(hex) {
  const normalized = normalizeHexColor(hex);
  if (!normalized) return null;
  return {
    r: parseInt(normalized.slice(1, 3), 16),
    g: parseInt(normalized.slice(3, 5), 16),
    b: parseInt(normalized.slice(5, 7), 16)
  };
}

function brightenHex(hex, ratio = 0.2) {
  const rgb = hexToRgb(hex);
  if (!rgb) return '#34d399';
  const brighten = (c) => Math.min(255, Math.round(c + (255 - c) * ratio));
  return `#${[brighten(rgb.r), brighten(rgb.g), brighten(rgb.b)].map(n => n.toString(16).padStart(2, '0')).join('')}`;
}

function getContrastText(hex) {
  const rgb = hexToRgb(hex);
  if (!rgb) return '#ffffff';
  const yiq = ((rgb.r * 299) + (rgb.g * 587) + (rgb.b * 114)) / 1000;
  return yiq >= 150 ? '#111827' : '#ffffff';
}

function getAccentPalette(accentValue) {
  if (typeof accentValue === 'string' && ACCENT_PRESETS[accentValue]) {
    const preset = ACCENT_PRESETS[accentValue];
    return {
      ...preset,
      contrast: getContrastText(preset.accent),
      hoverContrast: getContrastText(preset.hover)
    };
  }
  const accent = normalizeHexColor(accentValue) || '#22c55e';
  const rgb = hexToRgb(accent);
  if (!rgb) {
    const preset = ACCENT_PRESETS.emerald;
    return {
      ...preset,
      contrast: getContrastText(preset.accent),
      hoverContrast: getContrastText(preset.hover)
    };
  }
  const hover = brightenHex(accent, 0.2);
  return {
    accent,
    hover,
    soft: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`,
    contrast: getContrastText(accent),
    hoverContrast: getContrastText(hover)
  };
}

function updateAccentPickerUI(accentValue) {
  const normalized = normalizeHexColor(accentValue) || '#22c55e';
  const swatch = document.getElementById('accentPickerSwatch');
  const valueEl = document.getElementById('accentPickerValue');
  const input = document.getElementById('accentColorInput');
  if (swatch) swatch.style.background = normalized;
  if (valueEl) valueEl.textContent = normalized.toUpperCase();
  if (input) input.value = normalized;
}

// Persistência - Firestore ou localStorage
async function loadTasks() {
  if (typeof firebaseReady !== 'undefined' && firebaseReady && state.user) {
    try {
      const db = firebase.firestore();
      // Perfil do usuário (empresa / cargo)
      const userProfileDoc = await db.collection('users').doc(state.user.uid).get();
      if (userProfileDoc.exists) {
        state.userProfile = userProfileDoc.data();
      }
      if (state.userProfile?.companyId) {
        try {
          const companyDoc = await db.collection('companies')
            .doc(state.userProfile.companyId)
            .get();
          if (companyDoc.exists && Array.isArray(companyDoc.data().workingDays)) {
            state.workingDays = companyDoc.data().workingDays;
          }
        } catch (e) {
          console.error('Erro ao carregar dias de funcionamento da empresa:', e);
        }
      }

      const doc = await db.collection('users').doc(state.user.uid).collection('tasks').doc('data').get();
      if (doc.exists) {
        const data = doc.data();
        if (data.tasks) {
          state.tasks = data.tasks.map(mapLoadedTask);
        }
        if (data.readyTasks) {
          state.readyTasks = data.readyTasks;
        }
        // Mantém compatibilidade com versões antigas, mas só usa se não vier da empresa
        if (!state.workingDays && Array.isArray(data.workingDays)) {
          state.workingDays = data.workingDays;
        }
      }
    } catch (e) {
      console.error('Erro ao carregar do Firestore:', e);
    }
  } else {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        state.tasks = (parsed.tasks || []).map(mapLoadedTask);
        state.readyTasks = parsed.readyTasks || [];
        if (Array.isArray(parsed.workingDays)) {
          state.workingDays = parsed.workingDays;
        }
      }
    } catch (e) {
      console.error('Erro ao carregar tarefas:', e);
    }
  }
}

async function saveTasks() {
  if (typeof firebaseReady !== 'undefined' && firebaseReady && state.user) {
    try {
      const db = firebase.firestore();
      // Salva nas tarefas do usuário atual da tela: próprio usuário ou colaborador (quando admin está visualizando)
      const targetUserId = isViewingOtherUser() ? state.viewingUserId : state.user.uid;
      await db.collection('users').doc(targetUserId).collection('tasks').doc('data').set({
        tasks: state.tasks,
        readyTasks: state.readyTasks,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    } catch (e) {
      console.error('Erro ao salvar no Firestore:', e);
    }
  } else {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      tasks: state.tasks,
      readyTasks: state.readyTasks,
      workingDays: state.workingDays || getDefaultWorkingDays()
    }));
  }
}

// Calendário
function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  const monthTitle = document.getElementById('currentMonth');
  
  const year = state.currentDate.getFullYear();
  const month = state.currentDate.getMonth();
  monthTitle.textContent = `${MONTHS[month]} ${year}`;

  grid.innerHTML = WEEKDAYS.map(d => 
    `<div class="calendar-day-header">${d}</div>`
  ).join('');

  const firstDay = new Date(year, month, 1);
  const startDate = getWeekStart(firstDay);

  for (let i = 0; i < 42; i++) {
    const date = new Date(startDate);
    date.setDate(startDate.getDate() + i);
    
    const dayNum = date.getDate();
    const isOtherMonth = date.getMonth() !== month;
    const isToday = isSameDay(date, new Date());
    const isSelected = isSameDay(date, state.selectedDate);
    const hasTasks = getTasksForDate(date).length > 0;

    const dayEl = document.createElement('div');
    dayEl.className = 'calendar-day';
    if (isOtherMonth) dayEl.classList.add('other-month');
    if (isToday) dayEl.classList.add('today');
    if (isSelected) dayEl.classList.add('selected');
    if (hasTasks) dayEl.classList.add('has-tasks');
    
    dayEl.textContent = dayNum;
    dayEl.dataset.date = formatDateKey(date);
    dayEl.addEventListener('click', () => selectDate(date));
    
    grid.appendChild(dayEl);
  }
}

function selectDate(date) {
  state.selectedDate = date;
  renderCalendar();
  renderTasks();
  updateSelectedDateTitle();
}

// Dias úteis / empresa
function isWorkingDay(date, workingDays) {
  const days = workingDays && workingDays.length ? workingDays : getDefaultWorkingDays();
  return days.includes(date.getDay());
}

function adjustToPreviousWorkingDay(date, workingDays) {
  const days = workingDays && workingDays.length ? workingDays : getDefaultWorkingDays();
  const d = new Date(date);
  let guard = 0;
  while (!days.includes(d.getDay()) && guard < 31) {
    d.setDate(d.getDate() - 1);
    guard++;
  }
  return d;
}

function adjustToNextWorkingDay(date, workingDays) {
  const days = workingDays && workingDays.length ? workingDays : getDefaultWorkingDays();
  const d = new Date(date);
  let guard = 0;
  while (!days.includes(d.getDay()) && guard < 31) {
    d.setDate(d.getDate() + 1);
    guard++;
  }
  return d;
}

function getMonthlyEffectiveDateForTask(task, referenceDate, workingDays) {
  const year = referenceDate.getFullYear();
  const month = referenceDate.getMonth();
  const lastDay = new Date(year, month + 1, 0).getDate();
  // monthDay 0 = último dia do mês
  const monthDay = task.monthDay === 0 ? lastDay : (task.monthDay || 1);
  const clampedDay = Math.min(monthDay, lastDay);
  const base = new Date(year, month, clampedDay);
  const days = workingDays && workingDays.length ? workingDays : getDefaultWorkingDays();
  // Primeiro dia do mês: se for fora de serviço, usar o próximo dia útil
  if (clampedDay === 1 && !days.includes(base.getDay())) {
    return adjustToNextWorkingDay(base, workingDays);
  }
  return adjustToPreviousWorkingDay(base, workingDays);
}

// Equipe / permissões
function isAdmin() {
  return !!(state.userProfile && state.userProfile.role === 'admin');
}

function isViewingOtherUser() {
  return !!(state.viewingUserId && state.viewingUserId !== state.user?.uid);
}

async function saveCompanyWorkingDays() {
  if (!(typeof firebaseReady !== 'undefined' && firebaseReady &&
    state.user && state.userProfile && state.userProfile.companyId && isAdmin())) {
    return;
  }

  try {
    const db = firebase.firestore();
    await db.collection('companies')
      .doc(state.userProfile.companyId)
      .update({
        workingDays: state.workingDays || getDefaultWorkingDays(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
  } catch (e) {
    console.error('Erro ao salvar dias de funcionamento da empresa:', e);
  }
}

async function viewUserTasks(userId) {
  if (!(typeof firebaseReady !== 'undefined' && firebaseReady && state.user && isAdmin())) {
    return;
  }

  // Se selecionar o próprio admin, sai do modo de visualização (se estiver ativo)
  if (userId === state.user.uid) {
    await exitViewMode();
    return;
  }

  try {
    const db = firebase.firestore();

    const userDoc = await db.collection('users').doc(userId).get();
    if (!userDoc.exists) {
      alert('Usuário selecionado não encontrado.');
      return;
    }

    const profile = userDoc.data();
    const tasksDoc = await db.collection('users').doc(userId)
      .collection('tasks').doc('data').get();

    state.viewingUserId = userId;
    state.viewingUserName = profile.name || profile.email || 'Colaborador';

    state.userProfile = state.userProfile || {};

    if (tasksDoc.exists) {
      const data = tasksDoc.data();
      state.tasks = (data.tasks || []).map(mapLoadedTask);
      state.readyTasks = data.readyTasks || [];
      // workingDays continua vindo da empresa
    } else {
      state.tasks = [];
      state.readyTasks = [];
    }

    document.getElementById('teamModal')?.classList.remove('active');

    renderCalendar();
    renderTasks();
    renderReadyTasks();
    updateSelectedDateTitle();
    updateViewingInfoBanner();
  } catch (e) {
    console.error('Erro ao carregar tarefas do colaborador:', e);
    alert('Não foi possível carregar as tarefas deste colaborador.');
  }
}

async function exitViewMode() {
  // Sempre volta para as próprias tarefas, mesmo que o estado de visualização esteja inconsistente
  state.viewingUserId = null;
  state.viewingUserName = null;

  await loadTasks();
  renderCalendar();
  renderTasks();
  renderReadyTasks();
  updateSelectedDateTitle();
  updateViewingInfoBanner();
}

async function refreshTasks() {
  const btn = document.getElementById('refreshTasksBtn');
  const originalTitle = btn?.getAttribute('title') || 'Atualizar tarefas';
  if (btn) {
    btn.disabled = true;
    btn.setAttribute('aria-label', 'Atualizando…');
  }

  try {
    if (isViewingOtherUser() && typeof firebaseReady !== 'undefined' && firebaseReady && state.user) {
      const db = firebase.firestore();
      const tasksDoc = await db.collection('users').doc(state.viewingUserId)
        .collection('tasks').doc('data').get();
      if (tasksDoc.exists) {
        const data = tasksDoc.data();
        state.tasks = (data.tasks || []).map(mapLoadedTask);
        state.readyTasks = data.readyTasks || [];
      }
    } else {
      await loadTasks();
    }
    renderCalendar();
    renderTasks();
    renderReadyTasks();
    updateSelectedDateTitle();
    if (isViewingOtherUser()) updateViewingInfoBanner();
    if (btn) {
      btn.setAttribute('title', 'Atualizado!');
      btn.setAttribute('aria-label', 'Atualizado!');
      setTimeout(() => {
        btn.disabled = false;
        btn.setAttribute('title', originalTitle);
        btn.setAttribute('aria-label', originalTitle);
      }, 1500);
    }
  } catch (e) {
    console.error('Erro ao atualizar tarefas:', e);
    if (btn) {
      btn.disabled = false;
      btn.setAttribute('aria-label', originalTitle);
    }
  }
}

// Tarefas
function getTasksForDate(date) {
  const dateKey = formatDateKey(date);
  const dayOfWeek = date.getDay();

  return state.tasks.filter(task => {
    if (task.frequency === 'daily') return true;
    if (task.frequency === 'weekly') return task.weekDay === dayOfWeek;
    if (task.frequency === 'biweekly') return matchesBiweeklyOnDate(task, date);
    if (task.frequency === 'monthly') {
      const effective = getMonthlyEffectiveDateForTask(task, date, state.workingDays);
      return isSameDay(effective, date);
    }
    if (task.frequency === 'specific') return task.date === dateKey;
    return false;
  });
}

function isTaskCompleted(task, date) {
  const dateKey = formatDateKey(date);
  return task.completedDates?.includes(dateKey) ?? false;
}

async function toggleTaskComplete(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  const dateKey = formatDateKey(state.selectedDate);
  if (!task.completedDates) task.completedDates = [];
  
  const idx = task.completedDates.indexOf(dateKey);
  if (idx >= 0) {
    task.completedDates.splice(idx, 1);
  } else {
    task.completedDates.push(dateKey);
  }
  await saveTasks();
  renderTasks();
  renderCalendar();
}

async function deleteTask(taskId) {
  state.tasks = state.tasks.filter(t => t.id !== taskId);
  await saveTasks();
  renderTasks();
  renderCalendar();
}

// Tarefas pronta entrega
function renderReadyTasks() {
  const list = document.getElementById('readyTaskList');
  if (!list) return;

  if (state.readyTasks.length === 0) {
    list.innerHTML = `
      <li class="empty-state !rounded-xl !border !border-dashed !border-app-border !bg-app-secondary/30 !p-4 !text-center">
        <p class="!text-sm !text-app-muted">Nenhuma tarefa pronta entrega cadastrada</p>
      </li>
    `;
    refreshIcons();
    return;
  }

  list.innerHTML = state.readyTasks.map(task => {
    const completedClass = task.completed ? 'completed' : '';
    return `
    <li class="task-item ${completedClass} !rounded-xl !border !border-app-border !bg-app-secondary/40 !p-3 !transition-colors hover:!bg-app-secondary/70" data-id="${task.id}">
      <div class="task-controls !mb-2 !flex !items-center !justify-between !gap-2">
        <div class="task-checkbox !h-5 !w-5 !rounded !border !border-app-border !bg-app-card" role="button" tabindex="0" aria-label="Marcar como concluída"></div>
        <div class="task-actions !flex !items-center !gap-1.5">
          <button class="task-edit !inline-flex !h-8 !w-8 !items-center !justify-center !rounded-md !border !border-app-border !bg-app-card !text-sm !transition-colors hover:!border-app-accent hover:!text-app-accent" aria-label="Editar"><i data-lucide="pencil"></i></button>
          <button class="task-delete !inline-flex !h-8 !w-8 !items-center !justify-center !rounded-md !border !border-red-500/40 !bg-red-500/10 !text-lg !leading-none !text-red-300 !transition-colors hover:!bg-red-500/20" aria-label="Excluir"><i data-lucide="trash-2"></i></button>
        </div>
      </div>
      <div class="task-content !flex !flex-col !items-center !justify-center !gap-2 !text-center">
        <span class="task-title !text-center !text-sm !font-medium !text-app-text">${escapeHtml(task.title)}</span>
      </div>
    </li>
  `;
  }).join('');

  list.querySelectorAll('.task-item').forEach(item => {
    const id = item.dataset.id;
    item.querySelector('.task-checkbox').addEventListener('click', () => toggleReadyTaskComplete(id));
    const editBtn = item.querySelector('.task-edit');
    if (editBtn) {
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const task = state.readyTasks.find(t => t.id === id);
        if (task) openReadyTaskModal(task);
      });
    }
    item.querySelector('.task-delete').addEventListener('click', (e) => {
      e.stopPropagation();
      if (confirm('Excluir esta tarefa pronta entrega?')) deleteReadyTask(id);
    });
  });
  refreshIcons();
}

async function toggleReadyTaskComplete(id) {
  const task = state.readyTasks.find(t => t.id === id);
  if (!task) return;
  task.completed = !task.completed;
  await saveTasks();
  renderReadyTasks();
}

async function deleteReadyTask(id) {
  state.readyTasks = state.readyTasks.filter(t => t.id !== id);
  await saveTasks();
  renderReadyTasks();
}

async function clearCompletedReadyTasks() {
  const completedCount = state.readyTasks.filter(t => !!t.completed).length;
  if (completedCount === 0) {
    alert('Não há tarefas concluídas para excluir.');
    return;
  }
  if (!confirm(`Excluir ${completedCount} tarefa(s) pronta entrega concluída(s)?`)) {
    return;
  }
  state.readyTasks = state.readyTasks.filter(t => !t.completed);
  await saveTasks();
  renderReadyTasks();
}

// Administração - equipe
async function loadCompanyUsers() {
  if (!(typeof firebaseReady !== 'undefined' && firebaseReady && state.user && state.userProfile && state.userProfile.companyId && isAdmin())) {
    return;
  }

  try {
    const db = firebase.firestore();
    const snapshot = await db.collection('users')
      .where('companyId', '==', state.userProfile.companyId)
      .get();

    state.companyUsers = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));

    renderTeamList();
  } catch (e) {
    console.error('Erro ao carregar equipe da empresa:', e);
  }
}

function renderTeamList() {
  const listEl = document.getElementById('teamList');
  if (!listEl || !isAdmin()) return;

  if (!state.companyUsers.length) {
    listEl.innerHTML = `
      <p class="team-empty !rounded-lg !border !border-dashed !border-app-border !bg-app-secondary/30 !p-4 !text-center !text-sm !text-app-muted">Nenhum colaborador encontrado nesta empresa.</p>
    `;
    refreshIcons();
    return;
  }

  listEl.innerHTML = state.companyUsers.map(user => {
    const role = user.role || 'member';
    const isSelf = user.id === state.user?.uid;
    const name = user.name || '(Sem nome)';
    const email = user.email || '';

    const roleOptions = [
      { value: 'admin', label: 'Administrador' },
      { value: 'leader', label: 'Líder' },
      { value: 'member', label: 'Colaborador' }
    ].map(opt => {
      const selected = opt.value === role ? 'selected' : '';
      return `<option value="${opt.value}" ${selected}>${opt.label}</option>`;
    }).join('');

    const selfBadge = isSelf ? '<span class="team-self-badge !rounded-md !bg-app-accent/20 !px-2 !py-0.5 !text-xs !font-semibold !text-app-accent">Você</span>' : '';

    const excludeBtn = isSelf ? '' : `
      <button type="button" class="btn-danger team-exclude-btn !inline-flex !h-9 !items-center !justify-center !rounded-md !border !border-red-500/40 !bg-red-500/10 !px-3 !text-sm !font-medium !text-red-300 !transition-colors hover:!bg-red-500/20" aria-label="Excluir usuário" title="Excluir da empresa">
        Excluir
      </button>`;

    return `
      <div class="team-row !mb-2 !grid !grid-cols-1 !gap-2 !rounded-lg !border !border-app-border !bg-app-secondary/40 !p-3 md:!grid-cols-[minmax(0,1fr)_220px_auto] md:!items-center" data-id="${user.id}">
        <div class="team-col team-main">
          <div class="team-name !flex !items-center !gap-2 !text-sm !font-semibold !text-app-text">${escapeHtml(name)} ${selfBadge}</div>
          <div class="team-email !text-xs !text-app-muted md:!text-sm">${escapeHtml(email)}</div>
        </div>
        <div class="team-col team-role-col">
          <select class="team-role !h-9 !w-full !rounded-md !border !border-app-border !bg-app-card !px-2 !text-sm !text-app-text !outline-none focus:!border-app-accent focus:!ring-2 focus:!ring-app-accent/30 disabled:!opacity-60" ${isSelf ? 'disabled' : ''}>
            ${roleOptions}
          </select>
        </div>
        <div class="team-col team-actions-col !flex !items-center !gap-2">
          <button type="button" class="btn-secondary team-view-btn !inline-flex !h-9 !items-center !justify-center !rounded-md !border !border-app-border !bg-app-card !px-3 !text-sm !font-medium !text-app-subtle !transition-colors hover:!text-app-text">
            Ver tarefas
          </button>
          ${excludeBtn}
        </div>
      </div>
    `;
  }).join('');

  listEl.querySelectorAll('.team-row').forEach(row => {
    const userId = row.dataset.id;
    const viewBtn = row.querySelector('.team-view-btn');
    if (viewBtn) {
      viewBtn.addEventListener('click', async () => {
        await viewUserTasks(userId);
      });
    }
    const excludeBtn = row.querySelector('.team-exclude-btn');
    if (excludeBtn) {
      excludeBtn.addEventListener('click', () => excludeUserFromCompany(userId, row));
    }
  });
  refreshIcons();
}

async function excludeUserFromCompany(userId, rowEl) {
  if (!(typeof firebaseReady !== 'undefined' && firebaseReady && state.user && isAdmin())) {
    return;
  }
  const user = state.companyUsers.find(u => u.id === userId);
  const name = user?.name || user?.email || 'Este usuário';
  if (!confirm(`Excluir ${name} da empresa? Ele não terá mais acesso às tarefas da empresa.`)) {
    return;
  }
  try {
    const db = firebase.firestore();
    await db.collection('users').doc(userId).update({
      companyId: firebase.firestore.FieldValue.delete(),
      role: 'member'
    });
    state.companyUsers = state.companyUsers.filter(u => u.id !== userId);
    if (state.viewingUserId === userId) {
      await exitViewMode();
    }
    renderTeamList();
  } catch (e) {
    console.error('Erro ao excluir usuário:', e);
    alert('Não foi possível excluir o usuário. Tente novamente.');
  }
}

async function saveTeamChanges() {
  if (!(typeof firebaseReady !== 'undefined' && firebaseReady && state.user && isAdmin())) {
    return;
  }

  const listEl = document.getElementById('teamList');
  if (!listEl) return;

  const rows = Array.from(listEl.querySelectorAll('.team-row'));
  if (!rows.length) return;

  const db = firebase.firestore();
  const batch = db.batch();
  let hasChanges = false;

  rows.forEach(row => {
    const userId = row.dataset.id;
    const roleSelect = row.querySelector('.team-role');

    const original = state.companyUsers.find(u => u.id === userId) || {};
    const newRole = roleSelect && !roleSelect.disabled ? roleSelect.value : (original.role || 'member');
    const currentRole = original.role || 'member';

    if (newRole !== currentRole) {
      const ref = db.collection('users').doc(userId);
      batch.update(ref, { role: newRole });
      hasChanges = true;

      original.role = newRole;
      if (state.userProfile && userId === state.user.uid) {
        state.userProfile.role = newRole;
      }
    }
  });

  if (!hasChanges) {
    alert('Nenhuma alteração para salvar.');
    return;
  }

  try {
    await batch.commit();
    alert('Equipe atualizada com sucesso.');
    renderTeamList();

    updateUserRoleAndCode();
  } catch (e) {
    console.error('Erro ao salvar alterações da equipe:', e);
    alert('Erro ao salvar alterações da equipe. Tente novamente em alguns instantes.');
  }
}

function getFrequencyLabel(freq, task) {
  const base = { daily: 'Diária', weekly: 'Semanal', biweekly: 'Quinzenal', monthly: 'Mensal', specific: 'Específica' }[freq] || freq;
  if (freq === 'monthly' && task && task.monthDay === 0) return 'Mensal (último dia)';
  return base;
}

// Retorna uma data em que a tarefa aparece (para focar a tela após editar)
function getDisplayDateForTask(task) {
  if (!task) return state.selectedDate;
  const year = state.currentDate.getFullYear();
  const month = state.currentDate.getMonth();
  if (task.frequency === 'daily') return state.selectedDate;
  if (task.frequency === 'weekly') {
    const first = new Date(year, month, 1);
    const day = first.getDay();
    let diff = (task.weekDay - day + 7) % 7;
    if (diff < 0) diff += 7;
    const d = new Date(year, month, 1 + diff);
    if (d.getMonth() !== month) d.setDate(d.getDate() + 7);
    return d;
  }
  if (task.frequency === 'biweekly' && task.biweeklyStart != null && task.weekDay !== undefined) {
    const anchor = parseDateKeyLocal(task.biweeklyStart);
    if (!anchor) return state.selectedDate;
    const lastDom = new Date(year, month + 1, 0).getDate();
    for (let dom = 1; dom <= lastDom; dom++) {
      const cand = new Date(year, month, dom, 12, 0, 0, 0);
      if (matchesBiweeklyOnDate(task, cand)) return cand;
    }
    return anchor;
  }
  if (task.frequency === 'monthly') {
    return getMonthlyEffectiveDateForTask(task, state.currentDate, state.workingDays);
  }
  if (task.frequency === 'specific' && task.date) {
    const d = new Date(task.date + 'T12:00:00');
    if (!isNaN(d.getTime())) return d;
  }
  return state.selectedDate;
}

function renderTasks() {
  const list = document.getElementById('taskList');
  let tasks = getTasksForDate(state.selectedDate);
  // Exibir apenas tarefas normais (não prontas-entrega) nesta lista
  tasks = tasks.filter(t => !t.isReadyTask);

  if (tasks.length === 0) {
    list.innerHTML = `
      <li class="empty-state !rounded-xl !border !border-dashed !border-app-border !bg-app-secondary/30 !p-4 !text-center">
        <p class="!mb-3 !text-sm !text-app-muted">Nenhuma tarefa para este dia</p>
        <button class="add-task-btn !inline-flex !h-10 !items-center !justify-center !rounded-lg !bg-app-accent !px-4 !text-sm !font-semibold !text-white !transition-colors hover:!bg-app-accentHover" onclick="document.getElementById('addTaskBtn').click()">
          + Adicionar tarefa
        </button>
      </li>
    `;
    refreshIcons();
    return;
  }

  list.innerHTML = tasks.map(task => {
    const completed = isTaskCompleted(task, state.selectedDate);
    return `
      <li class="task-item ${completed ? 'completed' : ''} !rounded-xl !border !border-app-border !bg-app-secondary/40 !p-3 !transition-colors hover:!bg-app-secondary/70" data-id="${task.id}">
        <div class="task-controls !mb-2 !flex !items-center !justify-between !gap-2">
          <div class="task-checkbox !h-5 !w-5 !rounded !border !border-app-border !bg-app-card" role="button" tabindex="0" aria-label="Marcar como concluída"></div>
          <div class="task-actions !flex !items-center !gap-1.5">
            <button class="task-edit !inline-flex !h-8 !w-8 !items-center !justify-center !rounded-md !border !border-app-border !bg-app-card !text-sm !transition-colors hover:!border-app-accent hover:!text-app-accent" aria-label="Editar"><i data-lucide="pencil"></i></button>
            <button class="task-delete !inline-flex !h-8 !w-8 !items-center !justify-center !rounded-md !border !border-red-500/40 !bg-red-500/10 !text-lg !leading-none !text-red-300 !transition-colors hover:!bg-red-500/20" aria-label="Excluir"><i data-lucide="trash-2"></i></button>
          </div>
        </div>
        <div class="task-content !flex !flex-col !items-center !justify-center !gap-2 !text-center">
          <span class="task-title !text-center !text-sm !font-medium !text-app-text">${escapeHtml(task.title)}</span>
          <span class="task-badge ${task.frequency} !rounded-md !px-2 !py-1 !text-xs !font-semibold">${getFrequencyLabel(task.frequency, task)}</span>
        </div>
      </li>
    `;
  }).join('');

  list.querySelectorAll('.task-item').forEach(item => {
    const id = item.dataset.id;
    item.querySelector('.task-checkbox').addEventListener('click', () => toggleTaskComplete(id));
    const editBtn = item.querySelector('.task-edit');
    if (editBtn) {
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const task = state.tasks.find(t => t.id === id);
        if (task) openModal(task);
      });
    }
    item.querySelector('.task-delete').addEventListener('click', (e) => {
      e.stopPropagation();
      if (confirm('Excluir esta tarefa?')) deleteTask(id);
    });
  });
  refreshIcons();
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function updateSelectedDateTitle() {
  const title = document.getElementById('selectedDateTitle');
  const d = state.selectedDate;
  const isToday = isSameDay(d, new Date());
  const dateStr = `${d.getDate()} de ${MONTHS[d.getMonth()]}`;
  title.textContent = isToday ? `Tarefas de hoje (${dateStr})` : `Tarefas de ${dateStr}`;
}

function updateViewingInfoBanner() {
  const el = document.getElementById('viewingInfo');
  if (!el) return;

  if (isViewingOtherUser() && state.viewingUserName) {
    el.style.display = 'block';
    el.innerHTML = `
      <span class="viewing-info-text">Visualizando tarefas de ${escapeHtml(state.viewingUserName)}.</span>
      <button type="button" class="viewing-back-btn"><i data-lucide="arrow-left"></i> Voltar para minhas tarefas</button>
    `;
    const backBtn = el.querySelector('.viewing-back-btn');
    if (backBtn) {
      backBtn.addEventListener('click', async () => {
        state.viewingUserId = null;
        state.viewingUserName = null;
        await loadTasks();
        updateViewingInfoBanner();
        renderCalendar();
        renderTasks();
        updateSelectedDateTitle();
      });
    }
    refreshIcons();
  } else {
    el.style.display = 'none';
    el.textContent = '';
    el.onclick = null;
  }
}

// Modal tarefa
function openModal(task = null) {
  const modal = document.getElementById('taskModal');
  const form = document.getElementById('taskForm');
  const modalTitle = document.getElementById('modalTitle');
  const taskIdEl = document.getElementById('taskId');
  const frequencyGroup = document.getElementById('taskFrequency')?.closest('.form-group');

  form.reset();
  state.editingTaskId = null;
  state.editingReadyTaskId = null;

  if (task) {
    state.editingTaskId = task.id;
    modalTitle.textContent = 'Editar tarefa';
    if (taskIdEl) taskIdEl.value = task.id;
    document.getElementById('taskTitle').value = task.title;
    document.getElementById('taskFrequency').value = task.frequency;
    if (task.date) document.getElementById('taskDate').value = task.date;
    if (task.weekDay !== undefined) document.getElementById('taskWeekDay').value = task.weekDay;
    const lastDayCb = document.getElementById('taskLastDayOfMonth');
    if (task.monthDay === 0) {
      if (lastDayCb) lastDayCb.checked = true;
      document.getElementById('taskMonthDay').value = '';
    } else {
      if (lastDayCb) lastDayCb.checked = false;
      document.getElementById('taskMonthDay').value = task.monthDay || 1;
    }
  } else {
    modalTitle.textContent = 'Nova tarefa';
    if (taskIdEl) taskIdEl.value = '';
    document.getElementById('taskDate').value = formatDateKey(state.selectedDate);
    const lastDayCb = document.getElementById('taskLastDayOfMonth');
    if (lastDayCb) lastDayCb.checked = false;
    document.getElementById('taskMonthDay').value = '1';
  }
  updateFrequencyFields(task?.frequency || 'daily');

  modal.classList.add('active');
  document.getElementById('taskTitle').focus();
}

// Modal tarefa pronta entrega (reutiliza o mesmo modal, sem frequência)
function openReadyTaskModal(task = null) {
  const modal = document.getElementById('taskModal');
  const form = document.getElementById('taskForm');
  const modalTitle = document.getElementById('modalTitle');
  const assigneeGroup = document.getElementById('taskAssigneeGroup');
  const assigneeSelect = document.getElementById('taskAssignee');
  const frequencyGroup = document.getElementById('taskFrequency').closest('.form-group');

  form.reset();
  state.editingTaskId = null;
  state.editingReadyTaskId = null;

  // Esconde campos de recorrência para tarefas pronta entrega
  frequencyGroup.style.display = 'none';
  document.getElementById('datePickerGroup').style.display = 'none';
  document.getElementById('weekDayGroup').style.display = 'none';
  document.getElementById('monthDayGroup').style.display = 'none';

  // Para admins, mostrar seleção de colaborador ao criar tarefa pronta entrega
  if (assigneeGroup && assigneeSelect) {
    if (isAdmin()) {
      assigneeGroup.style.display = 'block';
      // Limpa e popula opções
      assigneeSelect.innerHTML = '<option value=\"\">Selecione um colaborador</option>';
      // Sempre incluir o próprio admin
      if (state.user && state.user.email) {
        const opt = document.createElement('option');
        opt.value = state.user.uid;
        opt.textContent = `${state.user.email} (você)`;
        assigneeSelect.appendChild(opt);
      }
      // Tenta usar a lista carregada da equipe, se existir
      if (state.companyUsers && state.companyUsers.length) {
        state.companyUsers.forEach(u => {
          const opt = document.createElement('option');
          opt.value = u.id;
          opt.textContent = u.name ? `${u.name} (${u.email || ''})` : (u.email || u.id);
          assigneeSelect.appendChild(opt);
        });
      }
    } else {
      assigneeGroup.style.display = 'none';
    }
  }

  if (task) {
    state.editingReadyTaskId = task.id;
    modalTitle.textContent = 'Editar tarefa pronta entrega';
    document.getElementById('taskId').value = task.id;
    document.getElementById('taskTitle').value = task.title;
  } else {
    modalTitle.textContent = 'Nova tarefa pronta entrega';
    document.getElementById('taskId').value = '';
  }

  modal.classList.add('active');
  document.getElementById('taskTitle').focus();
}

function closeModal() {
  document.getElementById('taskModal').classList.remove('active');
  state.editingTaskId = null;
}

function updateFrequencyFields(freq) {
  const dateGroup = document.getElementById('datePickerGroup');
  const weekGroup = document.getElementById('weekDayGroup');
  const monthGroup = document.getElementById('monthDayGroup');

  dateGroup.style.display = 'none';
  weekGroup.style.display = 'none';
  monthGroup.style.display = 'none';

  if (freq === 'weekly' || freq === 'biweekly') weekGroup.style.display = 'block';
  if (freq === 'monthly') monthGroup.style.display = 'block';
  if (freq === 'specific') dateGroup.style.display = 'block';
}

async function handleTaskSubmit(e) {
  e.preventDefault();
  
  const title = document.getElementById('taskTitle').value.trim();
  const frequencyField = document.getElementById('taskFrequency');
  const frequency = frequencyField && frequencyField.closest('.form-group').style.display !== 'none'
    ? frequencyField.value
    : null;
  const taskIdInput = document.getElementById('taskId');
  const taskId = (taskIdInput && taskIdInput.value) ? String(taskIdInput.value).trim() : '';

  // Se o campo de frequência estiver escondido, trata como tarefa pronta entrega
  if (!frequency) {
    const readyId = taskId || 'ready-' + Date.now();
    const taskData = {
      id: readyId,
      title,
      completed: false
    };

    const assigneeSelect = document.getElementById('taskAssignee');
    const assigneeGroupVisible = assigneeSelect && assigneeSelect.closest('.form-group').style.display !== 'none';

    // Admin ao designar tarefa pronta entrega deve sempre selecionar um colaborador (evita bug de gravar no perfil errado)
    if (isAdmin() && assigneeGroupVisible) {
      if (!assigneeSelect.value || assigneeSelect.value.trim() === '') {
        alert('Selecione um colaborador para atribuir a tarefa.');
        return;
      }
    }

    let targetUserId = state.user?.uid;
    if (isAdmin() && assigneeGroupVisible && assigneeSelect.value) {
      targetUserId = assigneeSelect.value;
    }

    // Se a tarefa pronta entrega for do próprio usuário logado
    if (!targetUserId || targetUserId === state.user?.uid) {
      if (state.editingReadyTaskId) {
        state.readyTasks = state.readyTasks.map(t => t.id === state.editingReadyTaskId ? { ...t, ...taskData } : t);
      } else {
        state.readyTasks.push(taskData);
      }

      await saveTasks();
      closeModal();
      renderReadyTasks();
    } else {
      // Atribui tarefa para outro colaborador no Firestore
      try {
        const db = firebase.firestore();
        const ref = db.collection('users').doc(targetUserId).collection('tasks').doc('data');
        const snap = await ref.get();
        const data = snap.exists ? snap.data() : {};
        const readyTasks = data.readyTasks || [];

        if (state.editingReadyTaskId) {
          // Atualização simples: substitui por id nos dados remotos
          const idx = readyTasks.findIndex(t => t.id === state.editingReadyTaskId);
          if (idx >= 0) {
            readyTasks[idx] = { ...readyTasks[idx], ...taskData };
          } else {
            readyTasks.push(taskData);
          }
        } else {
          readyTasks.push(taskData);
        }

        await ref.set({
          ...(data || {}),
          readyTasks,
          updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        // Se estivermos visualizando este colaborador, atualiza a lista local também
        if (isViewingOtherUser() && state.viewingUserId === targetUserId) {
          if (state.editingReadyTaskId) {
            state.readyTasks = state.readyTasks.map(t => t.id === state.editingReadyTaskId ? { ...t, ...taskData } : t);
          } else {
            state.readyTasks.push(taskData);
          }
          renderReadyTasks();
        }

        closeModal();
        alert('Tarefa pronta entrega atribuída com sucesso.');
      } catch (err) {
        console.error('Erro ao atribuir tarefa pronta entrega para colaborador:', err);
        alert('Não foi possível atribuir a tarefa para o colaborador.');
      }
    }
    return;
  } else {
    const taskData = {
      id: taskId || 'task-' + Date.now(),
      title,
      frequency,
      completedDates: []
    };

    if (frequency === 'weekly' || frequency === 'biweekly') {
      taskData.weekDay = parseInt(document.getElementById('taskWeekDay').value, 10);
    }
    if (frequency === 'biweekly') {
      const existingForAnchor = taskId ? state.tasks.find(t => t.id === taskId) : null;
      const wd = taskData.weekDay;
      if (existingForAnchor && existingForAnchor.frequency === 'biweekly' &&
          existingForAnchor.biweeklyStart && existingForAnchor.weekDay === wd) {
        taskData.biweeklyStart = existingForAnchor.biweeklyStart;
      } else {
        taskData.biweeklyStart = formatDateKey(firstWeekDayOnOrAfter(state.selectedDate, wd));
      }
    }
    if (frequency === 'monthly') {
      const lastDayCb = document.getElementById('taskLastDayOfMonth');
      if (lastDayCb && lastDayCb.checked) {
        taskData.monthDay = 0; // último dia do mês
      } else {
        const day = parseInt(document.getElementById('taskMonthDay').value, 10);
        taskData.monthDay = Math.min(31, Math.max(1, day || 1));
      }
    }
    if (frequency === 'specific') {
      taskData.date = document.getElementById('taskDate').value;
    }

    // Usar sempre o ID do formulário para saber qual tarefa atualizar (evita bug de atualizar a errada)
    const idToUpdate = taskId || null;
    const existing = idToUpdate ? state.tasks.find(t => t.id === idToUpdate) : null;

    if (existing) {
      taskData.id = existing.id;
      taskData.completedDates = existing.completedDates || [];
      state.tasks = state.tasks.map(t => t.id === existing.id ? taskData : t);
      // Após editar, focar na data em que a tarefa passa a aparecer para não "sumir"
      state.selectedDate = getDisplayDateForTask(taskData);
    } else {
      state.tasks.push(taskData);
    }
  }

  await saveTasks();
  closeModal();
  renderCalendar();
  renderTasks();
  updateSelectedDateTitle();
}

// Inicialização
document.addEventListener('DOMContentLoaded', async () => {
  normalizeCanonicalUrl();
  applySettings(loadSettings());

  // Auth
  if (typeof firebaseReady !== 'undefined' && firebaseReady) {
    firebase.auth().onAuthStateChanged(async (user) => {
      state.user = user;
      const logoutBtn = document.getElementById('logoutBtn');
      const userEmail = document.getElementById('userEmail');
      if (user) {
        userEmail.textContent = user.displayName || user.email;
        userEmail.style.display = 'inline';
        if (logoutBtn) logoutBtn.style.display = 'inline-block';
      } else {
        navigateToRoute('auth');
        return;
      }
      await loadTasks();
      updateHeaderUserIdentity();
      initApp();
    });
  } else {
    document.getElementById('userEmail').style.display = 'none';
    await loadTasks();
    initApp();
  }
});

function updateHeaderUserIdentity() {
  const userEl = document.getElementById('userEmail');
  if (!userEl) return;
  const profileName = state.userProfile?.name ? String(state.userProfile.name).trim() : '';
  const displayName = profileName || state.user?.displayName || state.user?.email || '';
  userEl.textContent = displayName;
  userEl.style.display = displayName ? 'inline' : 'none';
}

function initApp() {
  updateDailyMessage();
  initMobileSectionsNav();

  // Navegação calendário
  document.getElementById('prevMonth').addEventListener('click', () => {
    state.currentDate.setMonth(state.currentDate.getMonth() - 1);
    renderCalendar();
  });

  document.getElementById('nextMonth').addEventListener('click', () => {
    state.currentDate.setMonth(state.currentDate.getMonth() + 1);
    renderCalendar();
  });

  document.getElementById('addTaskBtn').addEventListener('click', () => {
    // Garante que campos de recorrência apareçam para tarefas normais
    document.getElementById('taskFrequency').closest('.form-group').style.display = 'block';
    updateFrequencyFields('daily');
    openModal();
  });

  const addReadyTaskBtn = document.getElementById('addReadyTaskBtn');
  if (addReadyTaskBtn) {
    addReadyTaskBtn.addEventListener('click', () => openReadyTaskModal());
  }
  const clearCompletedReadyBtn = document.getElementById('clearCompletedReadyBtn');
  if (clearCompletedReadyBtn) {
    clearCompletedReadyBtn.addEventListener('click', () => {
      clearCompletedReadyTasks();
    });
  }

  document.getElementById('taskFrequency').addEventListener('change', (e) => {
    updateFrequencyFields(e.target.value);
  });

  document.getElementById('taskForm').addEventListener('submit', handleTaskSubmit);

  document.getElementById('closeModal').addEventListener('click', closeModal);
  document.getElementById('cancelBtn').addEventListener('click', closeModal);

  document.getElementById('taskModal').addEventListener('click', (e) => {
    if (e.target.id === 'taskModal') closeModal();
  });

  // Configurações
  const settings = loadSettings();
  const themeRadio = document.querySelector(`input[name="theme"][value="${settings.theme}"]`);
  if (themeRadio) themeRadio.checked = true;
  updateAccentPickerUI(settings.accent);
  document.querySelectorAll('.size-option').forEach(o => o.classList.remove('active'));
  document.querySelector(`.size-option[data-size="${settings.fontSize}"]`)?.classList.add('active');

  // Dias de funcionamento (empresa)
  const workingDays = (state.workingDays && state.workingDays.length)
    ? state.workingDays
    : getDefaultWorkingDays();
  const dayCheckboxes = document.querySelectorAll('.working-day-input');
  dayCheckboxes.forEach(cb => {
    const val = parseInt(cb.value, 10);
    cb.checked = workingDays.includes(val);

    // Apenas administradores podem alterar os dias de funcionamento
    if (!isAdmin()) {
      cb.disabled = true;
    }
  });

  document.getElementById('refreshTasksBtn')?.addEventListener('click', () => {
    refreshTasks();
  });

  document.getElementById('settingsBtn').addEventListener('click', () => {
    document.getElementById('settingsModal').classList.add('active');
  });

  document.getElementById('closeSettings').addEventListener('click', () => {
    document.getElementById('settingsModal').classList.remove('active');
  });

  document.getElementById('settingsModal').addEventListener('click', (e) => {
    if (e.target.id === 'settingsModal') e.target.classList.remove('active');
  });

  document.querySelectorAll('input[name="theme"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const s = loadSettings();
      s.theme = e.target.value;
      saveSettings(s);
    });
  });

  const accentPickerBtn = document.getElementById('accentPickerBtn');
  const accentColorInput = document.getElementById('accentColorInput');
  if (accentPickerBtn && accentColorInput) {
    accentPickerBtn.addEventListener('click', () => {
      accentColorInput.click();
    });
    accentColorInput.addEventListener('input', (e) => {
      const chosen = normalizeHexColor(e.target.value);
      if (!chosen) return;
      const s = loadSettings();
      s.accent = chosen;
      saveSettings(s);
      updateAccentPickerUI(chosen);
    });
  }

  document.querySelectorAll('.size-option').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.size-option').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const s = loadSettings();
      s.fontSize = btn.dataset.size;
      saveSettings(s);
    });
  });

  // Atualizar dias de funcionamento ao marcar/desmarcar (apenas admin)
  if (isAdmin()) {
    document.querySelectorAll('.working-day-input').forEach(cb => {
      cb.addEventListener('change', () => {
        const selected = Array.from(document.querySelectorAll('.working-day-input'))
          .filter(c => c.checked)
          .map(c => parseInt(c.value, 10));

        state.workingDays = selected.length ? selected : getDefaultWorkingDays();
        saveCompanyWorkingDays();
        renderCalendar();
        renderTasks();
      });
    });
  }

  document.getElementById('logoutBtn')?.addEventListener('click', () => {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      firebase.auth().signOut();
      navigateToRoute('auth');
    }
  });

  // Painel de equipe (apenas administradores)
  const teamBtn = document.getElementById('teamBtn');
  const teamModal = document.getElementById('teamModal');
  if (teamBtn && teamModal && isAdmin()) {
    teamBtn.style.display = 'inline-block';

    teamBtn.addEventListener('click', async () => {
      await loadCompanyUsers();
      teamModal.classList.add('active');
    });

    document.getElementById('closeTeam')?.addEventListener('click', () => {
      teamModal.classList.remove('active');
    });

    document.getElementById('cancelTeamBtn')?.addEventListener('click', () => {
      teamModal.classList.remove('active');
    });

    teamModal.addEventListener('click', (e) => {
      if (e.target.id === 'teamModal') {
        teamModal.classList.remove('active');
      }
    });

    document.getElementById('saveTeamBtn')?.addEventListener('click', () => {
      saveTeamChanges();
    });
  } else if (teamBtn) {
    // Garante que o botão não apareça para não-admins
    teamBtn.style.display = 'none';
  }

  // PWA Install
  let deferredPrompt;
  const installBtn = document.getElementById('installBtn');
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;

  if (installBtn && isStandalone) {
    installBtn.style.display = 'none';
  }

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    if (installBtn) installBtn.style.display = 'inline-flex';
  });

  window.addEventListener('appinstalled', () => {
    if (installBtn) installBtn.style.display = 'none';
    deferredPrompt = null;
  });

  document.getElementById('installBtn')?.addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted' && installBtn) installBtn.style.display = 'none';
      deferredPrompt = null;
      return;
    }

    if (isIos && !isStandalone) {
      alert('Para instalar no iPhone/iPad, abra no Safari e use Compartilhar > Adicionar à Tela de Início.');
      return;
    }

    alert('Instalação indisponível neste momento. Tente pelo menu do navegador: "Instalar app" ou "Adicionar à tela inicial".');
  });

  renderCalendar();
  renderTasks();
  renderReadyTasks();
  updateSelectedDateTitle();
  updateMobileSectionVisibility();

  updateUserRoleAndCode();
  refreshIcons();
}

function initMobileSectionsNav() {
  const nav = document.getElementById('mobileSectionsNav');
  if (!nav) return;

  nav.querySelectorAll('.mobile-section-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.mobileSection = btn.dataset.section || 'agenda';
      updateMobileSectionVisibility();
    });
  });

  window.addEventListener('resize', updateMobileSectionVisibility);
}

function updateMobileSectionVisibility() {
  const isMobile = window.matchMedia('(max-width: 768px)').matches;
  const nav = document.getElementById('mobileSectionsNav');
  const buttons = nav ? Array.from(nav.querySelectorAll('.mobile-section-btn')) : [];
  const sections = Array.from(document.querySelectorAll('[data-mobile-section]'));
  const readySection = document.querySelector('.ready-tasks-section');
  const calendarSection = document.querySelector('.calendar-section');
  const tasksSection = document.querySelector('.tasks-section');

  if (!isMobile) {
    if (nav) nav.style.display = 'none';
    sections.forEach(section => {
      section.classList.remove('is-active');
      section.style.display = '';
    });
    return;
  }

  if (nav) nav.style.display = 'grid';
  if (!['ready', 'agenda'].includes(state.mobileSection)) {
    state.mobileSection = 'agenda';
  }

  buttons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.section === state.mobileSection);
  });

  // Controle explícito das 3 seções para evitar sobreposição no mobile.
  if (state.mobileSection === 'ready') {
    if (readySection) {
      readySection.classList.add('is-active');
      readySection.style.display = 'block';
    }
    if (calendarSection) {
      calendarSection.classList.remove('is-active');
      calendarSection.style.display = 'none';
    }
    if (tasksSection) {
      tasksSection.classList.remove('is-active');
      tasksSection.style.display = 'none';
    }
    return;
  }

  if (readySection) {
    readySection.classList.remove('is-active');
    readySection.style.display = 'none';
  }
  if (calendarSection) {
    calendarSection.classList.add('is-active');
    calendarSection.style.display = 'block';
  }
  if (tasksSection) {
    tasksSection.classList.add('is-active');
    tasksSection.style.display = 'block';
  }
}

function updateUserRoleAndCode() {
  const wrap = document.getElementById('userRoleCodeWrap');
  if (!wrap || !state.userProfile) return;

  const roleLabel = state.userProfile.role === 'admin' ? 'Administrador' :
    state.userProfile.role === 'leader' ? 'Líder' : 'Colaborador';
  const companyCode = (state.userProfile.companyId || '').trim();
  const showCodeBox = isAdmin() && companyCode;

  const roleClass = state.userProfile.role === 'admin' ? 'role-badge role-admin' :
    state.userProfile.role === 'leader' ? 'role-badge role-leader' : 'role-badge role-collab';

  let html = `<span class="${roleClass}">${roleLabel}</span>`;
  if (showCodeBox) {
    html += `
      <div class="company-code-box">
        <span class="company-code-label">Código da empresa</span>
        <span class="company-code-value" data-code="${escapeHtml(companyCode)}">${escapeHtml(companyCode)}</span>
        <button type="button" class="company-code-copy-btn" aria-label="Copiar código">Copiar</button>
      </div>`;
  }
  wrap.innerHTML = html;

  const copyBtn = wrap.querySelector('.company-code-copy-btn');
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      const codeEl = wrap.querySelector('.company-code-value');
      const code = (codeEl?.dataset?.code ?? codeEl?.textContent ?? '').trim();
      if (!code) return;

      function showCopied() {
        copyBtn.textContent = 'Copiado!';
        copyBtn.classList.add('copied');
        setTimeout(() => {
          copyBtn.textContent = 'Copiar';
          copyBtn.classList.remove('copied');
        }, 2000);
      }

      try {
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          await navigator.clipboard.writeText(code);
          showCopied();
          return;
        }
      } catch (_) {}

      // Fallback para HTTP ou navegadores sem Clipboard API
      try {
        const textarea = document.createElement('textarea');
        textarea.value = code;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.top = '0';
        document.body.appendChild(textarea);
        textarea.select();
        textarea.setSelectionRange(0, code.length);
        const ok = document.execCommand('copy');
        document.body.removeChild(textarea);
        if (ok) showCopied();
      } catch (_) {}
    });
  }
}
